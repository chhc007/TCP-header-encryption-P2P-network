from cryptography.hazmat.primitives.serialization import load_pem_private_key, load_pem_public_key
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend
import socket
import json
import base64

# 客户端公钥和私钥加载
with open("client_private_key.pem", "rb") as key_file:
    client_private_key = load_pem_private_key(key_file.read(), password=None, backend=default_backend())

client_public_key = client_private_key.public_key()

# 加载服务端公钥
with open("server_public_key.pem", "rb") as key_file:
    server_public_key = load_pem_public_key(key_file.read(), backend=default_backend())

# 创建 socket 对象
s = socket.socket()
port = 12345

# 连接到服务端
s.connect(('127.0.0.1', port))

# 加密并发送客户端公钥到服务端
encrypted_client_public_key = server_public_key.encrypt(
    client_public_key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo),
    ec.ECIES()
)
s.send(encrypted_client_public_key)

# 接收回传的客户端公钥
received_public_key = s.recv(1024)
assert received_public_key == client_public_key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
print("Client's public key successfully echoed back.")

# 生成临时的公钥和私钥对
temp_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
temp_public_key = temp_private_key.public_key()

# 使用服务端公钥加密临时公钥
encrypted_temp_public_key = server_public_key.encrypt(
    temp_public_key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo),
    ec.ECIES()
)

# 对临时公钥进行签名
signature = client_private_key.sign(
    encrypted_temp_public_key,
    ec.ECDSA(hashes.SHA256())
)

# 发送加密的临时公钥和签名
temp_public_key_info = {
    'public_key': base64.b64encode(encrypted_temp_public_key).decode('utf-8'),
    'signature': base64.b64encode(signature).decode('utf-8')
}
s.send(json.dumps(temp_public_key_info).encode('utf-8'))

# ECDH 密钥协商
shared_key = temp_private_key.exchange(ec.ECDH(), server_public_key)

# 派生对称加密密钥
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
    backend=default_backend()
).derive(shared_key)

print("Derived symmetric key:", derived_key)

# 关闭连接
s.close()
