from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
import socket
import threading
import json

class Bootnode:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.nodes = []
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        self.public_key = self.private_key.public_key()

    def print_public_key(self):
        # 将公钥转换为PEM格式并打印
        pem = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        print("Bootnode Public Key:\n", pem.decode())
    def start_server(self):
        # 启动服务器前打印公钥
        self.print_public_key()

        # 创建socket并绑定到指定的主机和端口
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind((self.host, self.port))
        server.listen(5)
        print(f"Bootnode running on {self.host}:{self.port}")

        while True:
            # 接受来自客户端的连接
            client, address = server.accept()
            print(f"Connected to {address}")
            # 使用线程来处理每个客户端
            threading.Thread(target=self.handle_client, args=(client,)).start()
    # 其他方法保持不变

    def handle_client(self, client):
        data = client.recv(1024).decode()
        if data:
            request = json.loads(data)
            action = request.get('action')

            if action == 'register':
                encrypted_temp_pub_key = request.get('encrypted_temp_pub_key')
                # 使用Bootnode的私钥解密
                temp_pub_key = self.decrypt_with_private_key(encrypted_temp_pub_key)

                # 注册新节点
                node_info = request.get('node_info')
                self.register_node(node_info)

                # 使用普通节点的临时公钥加密节点列表并发送
                encrypted_nodes_list = self.encrypt_with_public_key(json.dumps(self.nodes), temp_pub_key)
                client.sendall(encrypted_nodes_list)

    def decrypt_with_private_key(self, encrypted_data):
        # 使用Bootnode私钥解密
        return self.private_key.decrypt(
            encrypted_data,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

    def encrypt_with_public_key(self, data, public_key):
        # 使用普通节点的公钥加密
        return public_key.encrypt(
            data.encode(),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

# 启动Bootnode
bootnode = Bootnode('127.0.0.1', 5000)
bootnode.start_server()
