import socket
import threading
import json
import os
import time
class Node:
    def __init__(self, fingerprint, port):
        self.fingerprint = fingerprint
        self.port = port
        self.connected_nodes = {}
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind(('', self.port))
        self.socket.listen(5)
        self.known_nodes=None
        self.start_time=None
        print(f"Node {self.fingerprint} listening on port {self.port}")
        self.start_time = time.time()

    def listen_for_connections(self):
        while True:
            conn, addr = self.socket.accept()
            threading.Thread(target=self.handle_connection, args=(conn, addr)).start()



    def load_known_nodes(self):
        if os.path.exists('node.json'):
            with open('node.json', 'r') as file:
                return json.load(file)
        return []

    def connect_to_known_nodes(self, known_nodes):

        if not known_nodes:
            self.bootstrap()
            return

        for node in known_nodes:
            if node['fingerprint']==self.fingerprint:
                continue
            elif self.connected_nodes.get(node['fingerprint'])!=None:
                continue

            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect(('localhost', node['port']))
            self.send_fingerprint(client_socket)
            self.connected_nodes[node['fingerprint']] = client_socket
            #print(self.connected_nodes)
            print(f"Connected to node {node['fingerprint']}")
            threading.Thread(target=self.handle_connection, args=(client_socket, None)).start()
            print(f"Start handshake with node {node['fingerprint']}")
            time.sleep(0.010)  # 暂停1毫秒
            self.send_find_nodes(client_socket)
            # except Exception as e:
            #     print(f"Error connecting to node {node['fingerprint']}: {e}")

        if not self.connected_nodes:
            self.bootstrap()

    def bootstrap(self):
        print("Bootstrap process needs to be implemented.")

    def handle_connection(self, conn, addr):
        self.nodeid=None
        self.port=None
        if addr!=None:
            print(f"Connection from {addr}")
        while True:

                data = conn.recv(20480)
                if not data:
                    break
                print(len(data))
                message = json.loads(data.decode('utf-8'))
                self.nodeid,self.port=self.process_message(conn, message, addr)
                self.data = None
                #print("Proccessing:" + str(self.nodeid))
                if self.nodeid!=None:
                    self.findid=0
                    for node in self.known_nodes:
                        if node['fingerprint'] == self.nodeid:
                            self.findid=1
                            break
                    if self.findid==1:
                        self.findid=0
                    elif self.findid==0:
                        print("Adding to known list:" + str(self.nodeid))
                        self.known_nodes.append({"fingerprint": self.nodeid, "ip": addr[0], "port": self.port})
                        #print(self.known_nodes)

        #     except Exception as e:
        #         print(f"Error in connection: {e}")
        #
        #         break
        conn.close()

    def process_message(self, conn, message, addr):
        if message['type'] == 'fingerprint':
            remote_fingerprint = message['fingerprint']
            remote_port=message['msg']
            if remote_fingerprint not in self.connected_nodes:
                self.connected_nodes[remote_fingerprint] = conn
                print(f"Added node {remote_fingerprint} from {addr} to connected nodes")
                return remote_fingerprint,remote_port
            return None, None
        elif message['type'] == 'findnodes':
            print("Receive: FINDNODES")
            self.send_nodes(conn)
            return None,None
        elif message['type'] == 'nodes':
            print("Adding nodes to list")
            for node in message["nodes"]:
                self.known_nodes.append(node)
            self.connect_to_known_nodes(self.known_nodes)
            print("Receive: NODES")
            if len(self.connected_nodes) >= 1:
                end_time = time.time()
                execution_time = end_time - self.start_time
                print("代码执行时间为：", execution_time, "秒")
            return None,None
    def send_nodes(self, conn):
        print("Sending list")
        print(self.known_nodes)
        message = json.dumps({"type": "nodes", "nodes": self.known_nodes})
        conn.send(message.encode('utf-8'))
    def send_fingerprint(self, conn):
        message = json.dumps({"type": "fingerprint", "fingerprint": self.fingerprint,"msg":self.port})
        conn.send(message.encode('utf-8'))

    def send_handshake(self, conn):

        message = json.dumps({"type": "handshake", "msg": self.fingerprint})
        conn.send(message.encode('utf-8'))

    def send_find_nodes(self, conn):
        print("Send: FINDNODES")
        message = json.dumps({"type": "findnodes"})
        conn.send(message.encode('utf-8'))
    def find_nodes(self):
        #print("Send: FINDNODES")
        #print(self.connected_nodes)
        for node in self.connected_nodes:
            print(self.connected_nodes.get(node))
            conn=self.connected_nodes.get(node)
            self.send_find_nodes(conn)

    def execute_command(self, command):
        if command == 'peers':
            print(f"Connected nodes: {list(self.connected_nodes.keys())}")
        elif command == 'findnodes':
            self.find_nodes()
        elif command == 'showlist':
            print(type(self.known_nodes))
            print(f"Known nodes: {self.known_nodes}")
        else:
            print(f"Unknown command: {command}")

def main():
    node = Node("11111111", 5000)

    node.known_nodes = node.load_known_nodes()
    threading.Thread(target=node.listen_for_connections).start()
    threading.Thread(target=node.connect_to_known_nodes, args=(node.known_nodes,)).start()

    while True:
        command = input(">")
        node.execute_command(command)

if __name__ == "__main__":
    main()
