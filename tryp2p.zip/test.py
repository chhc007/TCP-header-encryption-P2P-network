import os

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
import hashlib
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, modes, algorithms
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import load_pem_public_key
def generate_and_save_ecc_keys(filename):
    # 生成 ECC 私钥
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

    # 序列化私钥并保存到文件
    with open(f"{filename}_private_key.pem", "wb") as key_file:
        key_file.write(
            private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
        )

    # 获取公钥
    public_key = private_key.public_key()

    # 序列化公钥并保存到文件
    with open(f"{filename}_public_key.pem", "wb") as key_file:
        key_file.write(
            public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
        )

# 生成并保存密钥对
generate_and_save_ecc_keys("client")
#generate_and_save_ecc_keys("server")


#my test







#private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
#public_key = private_key.public_key()
A_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

B_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

A_public_key=A_private_key.public_key()
B_public_key=B_private_key.public_key()


#:A send A_public_key to b
#:A send A temp_public_key ,, sign,, record
temp_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
temp_public_key=temp_private_key.public_key()

data = temp_public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
print(data)
signature=A_private_key.sign(data,ec.ECDSA(hashes.SHA256()))

#b: verify
# 验证签名
A_public_key_text=A_public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )

def verify_signature(public_key_pem, signature, data):
    public_key = load_pem_public_key(public_key_pem)
    try:
        # 尝试使用公钥验证签名
        public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception as e:
        print(f"Signature verification failed: {e}")
        return False

is_valid = verify_signature(A_public_key_text, signature, data)
print("Signature valid:", is_valid)

# ECDH 密钥协商 A
shared_key = temp_private_key.exchange(ec.ECDH(), B_public_key)
# 派生对称加密密钥
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
    backend=default_backend()
).derive(shared_key)
print("Derived symmetric key:", derived_key)

# ECDH 密钥协商 B
shared_key = B_private_key.exchange(ec.ECDH(), temp_public_key)
# 派生对称加密密钥
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
    backend=default_backend()
).derive(shared_key)
print("Derived symmetric key:", derived_key)



def encrypt_message(key, plaintext):
    """
    使用 AES 加密消息（含填充）
    :param key: 对称密钥
    :param plaintext: 明文消息
    :return: 密文和初始向量
    """
    # 生成随机初始向量 (IV)
    iv = os.urandom(16)

    # 创建填充器
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext) + padder.finalize()

    # 创建加密器
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    # 加密填充后的数据
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()

    return ciphertext, iv

def decrypt_message(key, ciphertext, iv):
    """
    使用 AES 解密消息（含去填充）
    :param key: 对称密钥
    :param ciphertext: 密文
    :param iv: 初始向量
    :return: 明文消息
    """
    # 创建解密器
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()

    # 解密数据
    padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

    # 创建去填充器
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()

    return plaintext

# 示例使用

plaintext = b"Secret message"

# 加密消息
ciphertext, iv = encrypt_message(derived_key, plaintext)

# 解密消息
decrypted_message = decrypt_message(derived_key, ciphertext, iv)

print("Original:", plaintext)
print("Encrypted:", ciphertext)
print("Decrypted:", decrypted_message)