import base64
import socket
import threading
import json
import os
import time
import os

from cryptography.hazmat.primitives.serialization import load_pem_private_key, load_pem_public_key
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
import hashlib
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, modes, algorithms
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import load_pem_public_key
import pickle
def encrypt_message(key, plaintext):
    """
    使用 AES 加密消息（含填充）
    :param key: 对称密钥
    :param plaintext: 明文消息
    :return: 密文和初始向量
    """
    # 生成随机初始向量 (IV)
    iv = os.urandom(16)

    # 创建填充器
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext) + padder.finalize()

    # 创建加密器
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    # 加密填充后的数据
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()

    return ciphertext, iv

def decrypt_message(key, ciphertext, iv):
    """
    使用 AES 解密消息（含去填充）
    :param key: 对称密钥
    :param ciphertext: 密文
    :param iv: 初始向量
    :return: 明文消息
    """
    # 创建解密器
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()

    # 解密数据
    padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

    # 创建去填充器
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()

    return plaintext
def base64_encode(data):
    """
    对数据进行 Base64 编码
    :param data: 要编码的数据（字节串）
    :return: Base64 编码后的字符串
    """
    return base64.b64encode(data).decode('utf-8')

def base64_decode(data):
    """
    对 Base64 编码的数据进行解码
    :param data: 要解码的 Base64 字符串
    :return: 原始数据（字节串）
    """
    return base64.b64decode(data.encode('utf-8'))
class Node:
    def __init__(self, fingerprint, port):
        self.fingerprint = fingerprint
        self.port = port
        self.connected_nodes = {}
        self.connected_nodes_and_session_key = {}
        self.connected_nodes_and_temp_public_key = {}
        self.connected_nodes_and_temp_private_key = {}
        self.connected_nodes_and_fingerprint={}
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind(('', self.port))
        self.socket.listen(5)
        self.known_nodes = None
        self.start_time = None
        print(f"Node {self.fingerprint} listening on port {self.port}")
        # 客户端公钥和私钥加载
        with open("private_key.pem", "rb") as key_file:
            self.private_key = load_pem_private_key(key_file.read(), password=None, backend=default_backend())

        # 加载服务端公钥
        with open("public_key.pem", "rb") as key_file:
            self.public_key = load_pem_public_key(key_file.read(), backend=default_backend())
            public_key_bytes = self.public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
                    )
        self.fingerprint= base64_encode(public_key_bytes)
        print(f"节点启动：指纹为{self.fingerprint}")
    def listen_for_connections(self):
        while True:
            conn, addr = self.socket.accept()
            threading.Thread(target=self.handle_connection, args=(conn, addr)).start()

    def load_known_nodes(self):
        if os.path.exists('node.json'):
            with open('node.json', 'r') as file:
                return json.load(file)
        return []

    def connect_to_known_nodes(self, known_nodes):
        if not known_nodes:
            self.bootstrap()
            return

        for node in known_nodes:
            if node['fingerprint'] == self.fingerprint:
                continue
            elif self.connected_nodes.get(node['fingerprint']) != None:
                continue

            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect(('localhost', node['port']))
            self.send_fingerprint(client_socket)
            self.connected_nodes[node['fingerprint']] = client_socket
            # print(self.connected_nodes)
            print(f"Connected to node {node['fingerprint']}")
            threading.Thread(target=self.handle_connection, args=(client_socket, None)).start()
            print(f"Start handshake with node {node['fingerprint']}")
            time.sleep(0.010)
            self.send_find_nodes(client_socket)
            self.connected_nodes_and_fingerprint[f"{client_socket}"]=node['fingerprint']
            if len(self.connected_nodes) == 3:
                end_time = time.time()
                execution_time = end_time - self.start_time
                print("代码执行时间为：", execution_time, "秒")
            # except Exception as e:
            #     print(f"Error connecting to node {node['fingerprint']}: {e}")

        if not self.connected_nodes:
            self.bootstrap()

    def bootstrap(self):
        print("Bootstrap process needs to be implemented.")

    def handle_connection(self, conn, addr):
        self.nodeid = None
        self.port = None
        if addr != None:
            print(f"Connection from {addr}")
        while True:

            data = conn.recv(20480)
            if not data:
                break
            print(len(data))
            message = json.loads(data.decode('utf-8'))
            self.nodeid, self.port = self.process_message(conn, message, addr)
            self.data = None
            # print("Proccessing:" + str(self.nodeid))
            if self.nodeid != None:
                self.findid = 0
                for node in self.known_nodes:
                    if node['fingerprint'] == self.nodeid:
                        self.findid = 1
                        break
                if self.findid == 1:
                    self.findid = 0
                elif self.findid == 0:
                    print("Adding to known list:" + str(self.nodeid))
                    self.known_nodes.append({"fingerprint": self.nodeid, "ip": addr[0], "port": self.port})
                    # print(self.known_nodes)

        #     except Exception as e:
        #         print(f"Error in connection: {e}")
        #
        #         break
        conn.close()
    def verify_signature(self,public_key, signature, data):
        public_key = load_pem_public_key(public_key)
        try:
            # 尝试使用公钥验证签名
            public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))
            return True
        except Exception as e:
            print(f"Signature verification failed: {e}")
            return False
    def process_message(self, conn, message, addr):
        if message['type'] == 'fingerprint':
            remote_fingerprint = message['fingerprint']
            remote_port = message['msg']
            if remote_fingerprint not in self.connected_nodes:
                self.connected_nodes_and_fingerprint[f"{conn}"]=remote_fingerprint
                self.connected_nodes[remote_fingerprint] = conn
                self.connected_nodes_and_session_key[f"{conn}"] = ""
                self.connected_nodes_and_temp_public_key[f"{conn}"] = ""
                self.connected_nodes_and_temp_private_key[f"{conn}"] = ""
                print(f"Added node {remote_fingerprint} from {addr} to connected nodes")
                return remote_fingerprint, remote_port
            return None, None
        elif message['type'] == 'findnodes':
            print("Receive: FINDNODES")
            isfirsttime = message['msg']
            if isfirsttime == "firsttime":
                self.send_handshake(conn)
            else:
                signature_txt=message['sign']
                signature=base64_decode(signature_txt)
                remotefingerprint=self.connected_nodes_and_fingerprint.get(f"{conn}")
                data = message['tmppubkey']

                remotepublickey=base64_decode(remotefingerprint)
                remotepublickey = serialization.load_pem_public_key(
                    remotepublickey,
                    backend=default_backend()
                )
                remotepublickey_txt=remotepublickey.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
                    )
                is_valid = self.verify_signature(remotepublickey_txt, signature,data.encode())
                if is_valid:
                    print("Signature valid:", is_valid)
                    # ECDH 密钥协商 B

                    remote_temp_publickey_txt=base64_decode(data)
                    remote_temp_publickey= serialization.load_pem_public_key(
                    remote_temp_publickey_txt,
                    backend=default_backend()
                         )
                    shared_key = self.private_key.exchange(ec.ECDH(), remote_temp_publickey)
                    # 派生对称加密密钥
                    derived_key = HKDF(
                        algorithm=hashes.SHA256(),
                        length=32,
                        salt=None,
                        info=b'handshake data',
                        backend=default_backend()
                    ).derive(shared_key)
                    self.connected_nodes_and_session_key[f"{conn}"] = derived_key
                    print(f"Derived symmetric key:{derived_key}")
                    self.send_nodes(conn,derived_key)
            return None, None
        elif message['type'] == 'nodes':
            print("Receive more nodes")
            sessionkey=self.connected_nodes_and_session_key.get(f"{conn}")
            print(f"use session key {sessionkey}")
            iv=base64_decode(message['iv'])
            if sessionkey!= None:

                print("Adding nodes to list")
                nodes_str = decrypt_message(sessionkey, base64_decode(message["nodes"]), iv)
                nodes = pickle.loads(nodes_str)
                for node in nodes:
                    self.known_nodes.append(node)
                self.connect_to_known_nodes(self.known_nodes)
                print("Receive: NODES")
                if len(self.connected_nodes) >= 3:
                    end_time = time.time()
                    execution_time = end_time - self.start_time
                    print("代码执行时间为：", execution_time, "秒")
                return None, None
            else:
                return None, None
        elif message['type'] == 'handshake':
            print("Send: FINDNODES 2")

            temp_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
            temp_public_key = temp_private_key.public_key()
            data = temp_public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )

            self.connected_nodes_and_temp_private_key[f"{conn}"] = temp_private_key
            self.connected_nodes_and_temp_public_key[f"{conn}"]= temp_public_key
            data = base64_encode(data)
            signature = self.private_key.sign(data.encode(), ec.ECDSA(hashes.SHA256()))
            signature_txt=base64_encode(signature)
            record = "IP+port+fingerprint"
            message = json.dumps(
                {"type": "findnodes", "msg": "notfirsttime", "tmppubkey": data, "sign": signature_txt, "record": record})
            # ECDH 密钥协商 A
            B_public_key_base64=self.connected_nodes_and_fingerprint.get(f"{conn}")
            B_public_key=base64_decode(B_public_key_base64)
            B_public_key=serialization.load_pem_public_key(B_public_key,backend=default_backend())
            shared_key = temp_private_key.exchange(ec.ECDH(), B_public_key)
            # 派生对称加密密钥
            derived_key = HKDF(
                algorithm=hashes.SHA256(),
                length=32,
                salt=None,
                info=b'handshake data',
                backend=default_backend()
            ).derive(shared_key)
            print("Derived symmetric key:", derived_key)
            self.connected_nodes_and_session_key[f"{conn}"]=derived_key
            conn.send(message.encode('utf-8'))
            return None, None

    def send_who_are_you(self, conn):
        message = json.dumps({"type": "whoareyou"})
        conn.send(message.encode('utf-8'))

    def send_nodes(self, conn,session_key):
        bytes_data = pickle.dumps(self.known_nodes)
        ennodes,iv=encrypt_message(session_key, bytes_data)
        ennodes=base64_encode(ennodes)
        iv=base64_encode(iv)
        message = json.dumps({"type": "nodes", "nodes": ennodes,"iv":iv})
        conn.send(message.encode('utf-8'))

    def send_fingerprint(self, conn):
        message = json.dumps({"type": "fingerprint", "fingerprint": self.fingerprint, "msg": self.port})
        conn.send(message.encode('utf-8'))

    def send_handshake(self, conn):

        message = json.dumps({"type": "handshake"})
        conn.send(message.encode('utf-8'))

    def send_find_nodes(self, conn):
        print("Send: FINDNODES")
        message = json.dumps({"type": "findnodes", "msg": "firsttime"})
        conn.send(message.encode('utf-8'))

    def find_nodes(self):
        # print("Send: FINDNODES")
        # print(self.connected_nodes)
        for node in self.connected_nodes:
            print(self.connected_nodes.get(node))
            conn = self.connected_nodes.get(node)
            self.send_find_nodes(conn)

    def execute_command(self, command):
        if command == 'peers':
            print(f"Connected nodes: {list(self.connected_nodes.keys())}")
        elif command == 'findnodes':
            self.find_nodes()
        elif command == 'showlist':
            print(type(self.known_nodes))
            print(f"Known nodes: {self.known_nodes}")
        else:
            print(f"Unknown command: {command}")


def main():
    node = Node("11111111", 5003)

    node.known_nodes = node.load_known_nodes()
    threading.Thread(target=node.listen_for_connections).start()
    threading.Thread(target=node.connect_to_known_nodes, args=(node.known_nodes,)).start()

    while True:
        command = input(">")
        node.execute_command(command)


if __name__ == "__main__":
    main()
