import os

from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend
import socket
import json
import base64

# 服务端公钥和私钥加载
with open("server_private_key.pem", "rb") as key_file:
    server_private_key = load_pem_private_key(key_file.read(), password=None, backend=default_backend())

server_public_key = server_private_key.public_key()

# 创建 socket 对象
s = socket.socket()
port = 12345
s.bind(('', port))
s.listen(5)
print("Server listening...")
def generate_keys_if_needed(filename):
    private_key_file = f"{filename}_private_key.pem"
    public_key_file = f"{filename}_public_key.pem"

    if not os.path.exists(private_key_file) or not os.path.exists(public_key_file):
        private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
        pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        )

        with open(private_key_file, 'wb') as f:
            f.write(pem)

        public_key = private_key.public_key()
        pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

        with open(public_key_file, 'wb') as f:
            f.write(pem)
while True:
    conn, addr = s.accept()
    print(f"Connected with {addr}")

    # 接收客户端的加密公钥
    encrypted_client_public_key = conn.recv(1024)
    client_public_key = server_private_key.decrypt(encrypted_client_public_key, ec.ECIES())
    print("Received and decrypted client's public key.")

    # 发送客户端公钥回客户端
    conn.send(client_public_key)

    # 接收客户端的临时公钥信息
    temp_public_key_info = json.loads(conn.recv(1024).decode('utf-8'))

    # 验证签名
    client_public_key_obj = serialization.load_pem_public_key(client_public_key, backend=default_backend())
    temp_public_key = temp_public_key_info['public_key']
    signature = base64.b64decode(temp_public_key_info['signature'])
    client_public_key_obj.verify(signature, temp_public_key.encode(), ec.ECDSA(hashes.SHA256()))

    print("Signature verified.")

    # 解密临时公钥
    temp_client_public_key = serialization.load_pem_public_key(base64.b64decode(temp_public_key), backend=default_backend())

    # ECDH 密钥协商
    shared_key = server_private_key.exchange(ec.ECDH(), temp_client_public_key)

    # 派生对称加密密钥
    derived_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b'handshake data',
        backend=default_backend()
    ).derive(shared_key)

    print("Derived symmetric key:", derived_key)

    # 关闭连接
    conn.close()
